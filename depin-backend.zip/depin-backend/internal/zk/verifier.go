package zk

import (
	"bytes"
	_ "embed"
	"encoding/json"
	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark/backend/groth16"
	"github.com/consensys/gnark/frontend"
	"log"
)

//go:embed circuit/verification_key.json
var vkJSON []byte

var verifyingKey groth16.VerifyingKey

func init() {
	verifyingKey = groth16.NewVerifyingKey(ecc.BN254)
	r := bytes.NewReader(vkJSON)
	if _, err := verifyingKey.ReadFrom(r); err != nil {
		log.Fatal("Failed to load verification key:", err)
	}
}

// Public API: Oracle 和 Handler 直接调用
func VerifyProof(proofData, publicInputs []byte) (bool, error) {
	proof := groth16.NewProof(ecc.BN254)
	if _, err := proof.ReadFrom(bytes.NewReader(proofData)); err != nil {
		return false, err
	}

	var inputs []frontend.Variable
	if err := json.Unmarshal(publicInputs, &inputs); err != nil {
		return false, err
	}

	err := groth16.Verify(proof, verifyingKey, inputs)
	return err == nil, err
}
