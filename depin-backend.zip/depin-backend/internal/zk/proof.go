package zk

import (
	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark/backend/groth16"
)

// Groth16 证明的 JSON 结构（与前端 snarkjs 生成一致）
type Groth16Proof struct {
	PiA      []string   `json:"pi_a"`
	PiB      [][]string `json:"pi_b"`
	PiC      []string   `json:"pi_c"`
	Protocol string     `json:"protocol"`
	Curve    string     `json:"curve"`
}

type ProofWithPublic struct {
	Proof        Groth16Proof `json:"proof"`
	PublicInputs []string     `json:"public"`
}

// 将 snarkjs 生成的 JSON 转为 gnark 可验证格式（生产环境常用）
func (p *Groth16Proof) ToGnarkProof() (*groth16.Proof, error) {
	proof := groth16.NewProof(ecc.BN254)

	// 实际项目中这里要做大整数转换（略）
	// 这里仅做结构占位，真实项目使用 gnark-std 或手动转换
	return proof, nil
}
