package repository

import (
	"depin-backend/internal/model"
	"gorm.io/gorm"
)

type DeviceRepository struct {
	db *gorm.DB
}

func NewDeviceRepository(db *gorm.DB) *DeviceRepository {
	return &DeviceRepository{db: db}
}

func (r *DeviceRepository) Create(device *model.Device) error {
	return r.db.Create(device).Error
}

func (r *DeviceRepository) FindByDeviceID(deviceID string) (*model.Device, error) {
	var device model.Device
	err := r.db.Unscoped().Where("device_id = ?", deviceID).First(&device).Error
	if err != nil {
		return nil, err
	}
	return &device, nil
}

func (r *DeviceRepository) FindByOwner(address string) ([]model.Device, error) {
	var devices []model.Device
	err := r.db.Where("owner_address = ?", address).Find(&devices).Error
	return devices, err
}

func (r *DeviceRepository) UpdateNFTTokenID(deviceID string, tokenID uint64) error {
	return r.db.Model(&model.Device{}).
		Where("device_id = ?", deviceID).
		Update("nft_token_id", tokenID).Error
}

func (r *DeviceRepository) IncrementUsage(deviceID string, usage uint64) error {
	return r.db.Model(&model.Device{}).
		Where("device_id = ?", deviceID).
		Updates(map[string]interface{}{
			"total_usage":    gorm.Expr("total_usage + ?", usage),
			"last_submitted": gorm.Expr("NOW()"),
		}).Error
}
