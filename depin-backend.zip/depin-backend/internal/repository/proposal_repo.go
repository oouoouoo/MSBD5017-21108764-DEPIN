package repository

import (
	"depin-backend/internal/model"
	"gorm.io/gorm"
)

type ProposalRepository struct {
	db *gorm.DB
}

func NewProposalRepository(db *gorm.DB) *ProposalRepository {
	return &ProposalRepository{db: db}
}

func (r *ProposalRepository) Upsert(proposal *model.Proposal) error {
	return r.db.
		Where("proposal_id = ?", proposal.ProposalID).
		Assign(*proposal).
		FirstOrCreate(proposal).Error
}

func (r *ProposalRepository) ListActive() ([]model.Proposal, error) {
	var proposals []model.Proposal
	err := r.db.Where("status IN ?", []model.ProposalStatus{
		model.ProposalPending,
		model.ProposalActive,
	}).Order("created_at DESC").Find(&proposals).Error
	return proposals, err
}
