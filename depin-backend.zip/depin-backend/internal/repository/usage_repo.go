package repository

import (
	"depin-backend/internal/model"
	"gorm.io/gorm"
	"time"
)

type UsageRepository struct {
	db *gorm.DB
}

func NewUsageRepository(db *gorm.DB) *UsageRepository {
	return &UsageRepository{db: db}
}

func (r *UsageRepository) BatchCreate(records []*model.UsageRaw) error {
	return r.db.CreateInBatches(records, 100).Error
}

func (r *UsageRepository) CleanupOldRaw(olderThan time.Duration) (int64, error) {
	result := r.db.Where("created_at < ?", time.Now().Add(-olderThan)).Delete(&model.UsageRaw{})
	return result.RowsAffected, result.Error
}

// 定时任务：每小时执行一次
// usageRepo.CleanupOldRaw(1 * time.Hour)
