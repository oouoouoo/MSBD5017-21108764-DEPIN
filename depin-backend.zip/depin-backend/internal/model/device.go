package model

import (
	"gorm.io/gorm"
	"time"
)

type DeviceType string

const (
	DeviceTypeEV  DeviceType = "EV_CHARGER"
	DeviceTypeGPU DeviceType = "GPU_NODE"
)

type Device struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`

	// 用户自定义唯一ID（全局唯一）
	DeviceID      string     `gorm:"uniqueIndex;size:64;not null" json:"device_id"`
	OwnerAddress  string     `gorm:"size:42;index;not null" json:"owner_address"` // 0x...
	Type          DeviceType `gorm:"type:varchar(20);not null" json:"type"`
	PublicKey     string     `gorm:"size:132;not null" json:"public_key"` // 设备公钥（hex）
	NFTTokenID    *uint64    `gorm:"index" json:"nft_token_id,omitempty"` // mint 成功后回写
	IPFSCID       string     `gorm:"size:100" json:"ipfs_cid,omitempty"`  // 设备照片/规格
	IsActive      bool       `gorm:"default:true" json:"is_active"`
	TotalUsage    uint64     `gorm:"default:0" json:"total_usage"` // 累计 kWh 或 GPU 小时
	LastSubmitted time.Time  `json:"last_submitted,omitempty"`
}
