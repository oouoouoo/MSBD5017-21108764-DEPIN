package model

import (
	"gorm.io/gorm"
	"time"
)

type UsageRaw struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	CreatedAt time.Time      `gorm:"index:idx_created" json:"created_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`

	DeviceID  string    `gorm:"size:64;index:idx_device" json:"device_id"`
	Timestamp time.Time `gorm:"index:idx_created" json:"timestamp"`
	PowerW    float64   `json:"power_w"`                   // 瞬时功率（EV）或 GPU 利用率
	DurationS uint32    `json:"duration_s"`                // 本条数据覆盖秒数
	RawData   []byte    `gorm:"type:bytea" json:"-"`       // 加密原始采样点（不上链）
	Signature string    `gorm:"size:132" json:"signature"` // 设备签名
	IPFSCID   string    `gorm:"size:100" json:"ipfs_cid,omitempty"`
}

// 自动清理：1小时后删除（在服务启动时跑定时任务）
func (UsageRaw) TableName() string {
	return "usage_raw"
}
