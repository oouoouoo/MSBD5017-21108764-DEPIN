package model

import (
	_ "gorm.io/gorm"
	"math/big"
	"time"
)

type ProposalStatus string

const (
	ProposalPending   ProposalStatus = "PENDING"
	ProposalActive    ProposalStatus = "ACTIVE"
	ProposalSucceeded ProposalStatus = "SUCCEEDED"
	ProposalDefeated  ProposalStatus = "DEFEATED"
	ProposalExecuted  ProposalStatus = "EXECUTED"
)

type Proposal struct {
	ID        uint      `gorm:"primarykey" json:"id"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`

	ProposalID   *big.Int       `gorm:"serializer:json" json:"proposal_id"` // chain 上 uint256
	Proposer     string         `gorm:"size:42" json:"proposer"`
	Description  string         `gorm:"type:text" json:"description"`
	Status       ProposalStatus `gorm:"type:varchar(20);index" json:"status"`
	StartBlock   *big.Int       `gorm:"serializer:json" json:"start_block,omitempty"`
	EndBlock     *big.Int       `gorm:"serializer:json" json:"end_block,omitempty"`
	ForVotes     *big.Int       `gorm:"serializer:json" json:"for_votes"`
	AgainstVotes *big.Int       `gorm:"serializer:json" json:"against_votes"`
	ExecutedAt   *time.Time     `json:"executed_at,omitempty"`
}
