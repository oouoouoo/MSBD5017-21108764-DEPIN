package middleware

import (
	"depin-backend/config"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"net/http"
	"strings"
)

func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" || !strings.HasPrefix(authHeader, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing token"})
			return
		}

		tokenStr := strings.TrimPrefix(authHeader, "Bearer ")

		// Step 1: 验证 JWT
		token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (interface{}, error) {
			return []byte(config.App.JWTSecret), nil
		})

		if err != nil || !token.Valid {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid jwt"})
			return
		}

		claims, ok := token.Claims.(jwt.MapClaims)
		if !ok {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid claims"})
			return
		}

		address, ok := claims["address"].(string)
		if !ok {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing address"})
			return
		}

		// Step 2: 可选 - 再次验证 nonce（防重放）
		// nonce := c.GetHeader("X-Nonce")
		// if !utils.VerifyNonce(address, nonce) { ... }

		c.Set("user_address", address)
		c.Next()
	}
}

// Oracle 专用密钥认证（生产环境用 HMAC 或白名单）
func OracleAuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		apiKey := c.GetHeader("X-Oracle-Key")
		if apiKey != config.App.OracleAPIKey {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "invalid oracle key"})
			return
		}
		c.Next()
	}
}
