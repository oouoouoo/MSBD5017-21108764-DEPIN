package service

import (
	"depin-backend/internal/blockchain"
	"depin-backend/internal/model"
	"depin-backend/internal/repository"
	"math/big"
)

type GovernanceService struct {
	proposalRepo *repository.ProposalRepository
}

func NewGovernanceService(repo *repository.ProposalRepository) *GovernanceService {
	return &GovernanceService{proposalRepo: repo}
}

// 同步链上最新提案到本地缓存
func (s *GovernanceService) SyncProposals() error {
	latest, _ := blockchain.GetLatestProposalID()

	for i := int64(1); i <= latest.Int64(); i++ {
		prop, err := blockchain.GetProposal(big.NewInt(i))
		if err != nil {
			continue
		}

		dbProp := &model.Proposal{
			ProposalID:   prop.ID,
			Proposer:     prop.Proposer,
			Description:  prop.Description,
			Status:       model.ProposalStatus(prop.Status),
			ForVotes:     prop.ForVotes,
			AgainstVotes: prop.AgainstVotes,
		}
		s.proposalRepo.Upsert(dbProp)
	}
	return nil
}
