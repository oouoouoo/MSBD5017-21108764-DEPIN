package service

import (
	"depin-backend/internal/model"
	"depin-backend/internal/repository"
)

type RewardService struct {
	deviceRepo *repository.DeviceRepository
}

func NewRewardService(repo *repository.DeviceRepository) *RewardService {
	return &RewardService{deviceRepo: repo}
}

type LeaderboardEntry struct {
	Rank         int     `json:"rank"`
	DeviceID     string  `json:"device_id"`
	Owner        string  `json:"owner"`
	TotalUsage   uint64  `json:"total_usage"`
	RewardEarned float64 `json:"reward_estimated_reward"`
}

// 全网排行榜（每日更新缓存或实时算）
func (s *RewardService) GetLeaderboard(limit int) ([]LeaderboardEntry, error) {
	var devices []model.Device
	if err := s.deviceRepo.DB().Order("total_usage DESC").Limit(limit).Find(&devices).Error; err != nil {
		return nil, err
	}

	entries := make([]LeaderboardEntry, len(devices))
	for i, d := range devices {
		entries[i] = LeaderboardEntry{
			Rank:         i + 1,
			DeviceID:     d.DeviceID,
			Owner:        d.OwnerAddress,
			TotalUsage:   d.TotalUsage,
			RewardEarned: float64(d.TotalUsage) * 1.0, // 1 token per unit
		}
	}
	return entries, nil
}
