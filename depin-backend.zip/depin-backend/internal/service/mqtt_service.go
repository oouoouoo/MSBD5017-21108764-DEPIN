package service

import (
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"log"
)

type MQTTService struct {
	client mqtt.Client
}

func NewMQTTService(broker string) *MQTTService {
	opts := mqtt.NewClientOptions().AddBroker(broker).SetClientID("depin-oracle")
	client := mqtt.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}
	return &MQTTService{client: client}
}

type Heartbeat struct {
	DeviceID  string  `json:"device_id"`
	Power     float64 `json:"power_w"`
	Timestamp int64   `json:"ts"`
}

func (s *MQTTService) SubscribeUsage(topic string, handler func([]byte)) {
	s.client.Subscribe(topic, 1, func(_ mqtt.Client, msg mqtt.Message) {
		handler(msg.Payload())
		msg.Ack()
	})
}
