package service

import (
	"bytes"
	shell "github.com/ipfs/go-ipfs-api"
)

type IPFSService struct {
	sh *shell.Shell
}

func NewIPFSService(url string) *IPFSService {
	return &IPFSService{sh: shell.NewShell(url)}
}

func (s *IPFSService) UploadUsageLog(deviceID string, data []byte) (string, error) {
	reader := bytes.NewReader(data)
	cid, err := s.sh.Add(reader)
	if err != nil {
		return "", err
	}
	return cid, nil
}
