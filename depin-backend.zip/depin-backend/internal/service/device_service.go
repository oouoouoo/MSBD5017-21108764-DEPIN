package service

import (
	"crypto/rand"
	"depin-backend/internal/blockchain"
	"depin-backend/internal/model"
	"depin-backend/internal/repository"
	"depin-backend/pkg/utils"
	"encoding/hex"
	"errors"
)

type DeviceService struct {
	deviceRepo *repository.DeviceRepository
}

func NewDeviceService(repo *repository.DeviceRepository) *DeviceService {
	return &DeviceService{deviceRepo: repo}
}

type RegisterRequest struct {
	DeviceID     string `json:"device_id" binding:"required"`
	Type         string `json:"type" binding:"required,oneof=EV_CHARGER GPU_NODE"`
	OwnerAddress string `json:"owner_address" binding:"required"`
	PublicKey    string `json:"public_key" binding:"required"` // hex
	Signature    string `json:"signature" binding:"required"`
	Challenge    string `json:"challenge" binding:"required"`
}

type RegisterResponse struct {
	DeviceID   string  `json:"device_id"`
	NFTTokenID *uint64 `json:"nft_token_id,omitempty"`
	TxHash     string  `json:"tx_hash"`
	Status     string  `json:"status"`
}

// 生成一次性挑战码
func (s *DeviceService) GenerateChallenge() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

// 注册设备 + mint NFT
func (s *DeviceService) RegisterDevice(req *RegisterRequest) (*RegisterResponse, error) {
	// 1. 验证设备签名
	if !utils.VerifyDeviceSignature(req.PublicKey, req.Challenge, req.Signature) {
		return nil, errors.New("invalid device signature")
	}

	// 2. 防重放
	if _, err := s.deviceRepo.FindByDeviceID(req.DeviceID); err == nil {
		return nil, errors.New("device_id already registered")
	}

	// 3. 写库
	device := &model.Device{
		DeviceID:     req.DeviceID,
		OwnerAddress: req.OwnerAddress,
		Type:         model.DeviceType(req.Type),
		PublicKey:    req.PublicKey,
		IsActive:     true,
	}
	if err := s.deviceRepo.Create(device); err != nil {
		return nil, err
	}

	// 4. 调用合约 mint NFT
	tokenID, txHash, err := blockchain.MintDeviceNFT(req.OwnerAddress, req.DeviceID)
	if err != nil {
		return nil, err
	}

	// 5. 回写 NFT ID
	s.deviceRepo.UpdateNFTTokenID(req.DeviceID, tokenID)

	return &RegisterResponse{
		DeviceID:   req.DeviceID,
		NFTTokenID: &tokenID,
		TxHash:     txHash,
		Status:     "success",
	}, nil
}
