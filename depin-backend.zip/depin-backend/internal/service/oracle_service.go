package service

import (
	"depin-backend/internal/blockchain"
	"depin-backend/internal/repository"
	"depin-backend/internal/zk"
	"errors"
)

type OracleService struct {
	deviceRepo  *repository.DeviceRepository
	usageRepo   *repository.UsageRepository
	ipfsService *IPFSService
}

func NewOracleService(d *repository.DeviceRepository, u *repository.UsageRepository, i *IPFSService) *OracleService {
	return &OracleService{deviceRepo: d, usageRepo: u, ipfsService: i}
}

type OracleSubmitRequest struct {
	DeviceID     string   `json:"device_id"`
	TotalUsage   uint64   `json:"total_usage"`   // 本小时累计
	Proof        []byte   `json:"proof"`         // zk-SNARKs 300字节
	PublicInputs []string `json:"public_inputs"` // ["prevTotal","newTotal","pubKeyHash",...]
}

func (s *OracleService) SubmitUsageData(req *OracleSubmitRequest) (string, error) {
	// 1. 验证设备存在
	device, err := s.deviceRepo.FindByDeviceID(req.DeviceID)
	if err != nil || !device.IsActive {
		return "", errors.New("device not found or inactive")
	}

	// 2. 验证 ZK 证明（最硬核一步）
	ok, err := zk.VerifyProof(req.Proof, req.PublicInputs)
	if !ok || err != nil {
		return "", errors.New("invalid zk proof: " + err.Error())
	}

	// 3. 上传完整原始日志到 IPFS（可选）
	cid, _ := s.ipfsService.UploadUsageLog(req.DeviceID, req.Proof) // 实际传原始数据

	// 4. 链上提交
	txHash, err := blockchain.SubmitUsageData(req.DeviceID, req.TotalUsage, cid)
	if err != nil {
		return "", err
	}

	// 5. 更新本地累计
	s.deviceRepo.IncrementUsage(req.DeviceID, req.TotalUsage)

	return txHash, nil
}
