package handler

import (
	"depin-backend/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type GovernanceHandler struct {
	service *service.GovernanceService
}

func NewGovernanceHandler(s *service.GovernanceService) *GovernanceHandler {
	return &GovernanceHandler{service: s}
}

func (h *GovernanceHandler) ListProposals(c *gin.Context) {
	// 先同步最新
	if err := h.service.SyncProposals(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "sync failed"})
		return
	}

	proposals, err := h.service.GetActiveProposals()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"proposals": proposals})
}
