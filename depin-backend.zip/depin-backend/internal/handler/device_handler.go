package handler

import (
	"depin-backend/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type DeviceHandler struct {
	service *service.DeviceService
}

func NewDeviceHandler(s *service.DeviceService) *DeviceHandler {
	return &DeviceHandler{service: s}
}

func (h *DeviceHandler) GenerateChallenge(c *gin.Context) {
	challenge, err := h.service.GenerateChallenge()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to generate challenge"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"challenge": challenge})
}

func (h *DeviceHandler) RegisterDevice(c *gin.Context) {
	var req service.RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	resp, err := h.service.RegisterDevice(&req)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, resp)
}

func (h *DeviceHandler) GetDeviceStatus(c *gin.Context) {
	deviceID := c.Param("id")
	device, err := h.service.GetDeviceStatus(deviceID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "device not found"})
		return
	}
	c.JSON(http.StatusOK, device)
}

func NewRewardHandler(s *service.RewardService) *RewardHandler {
	return &RewardHandler{service: s}
}

type RewardHandler struct {
	service *service.RewardService
}