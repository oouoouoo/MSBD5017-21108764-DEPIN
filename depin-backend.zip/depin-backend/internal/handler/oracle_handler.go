package handler

import (
	"depin-backend/internal/service"
	"github.com/gin-gonic/gin"
	"net/http"
)

type OracleHandler struct {
	service *service.OracleService
}

func NewOracleHandler(s *service.OracleService) *OracleHandler {
	return &OracleHandler{service: s}
}

func (h *OracleHandler) SubmitUsageData(c *gin.Context) {
	var req service.OracleSubmitRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	txHash, err := h.service.SubmitUsageData(&req)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"tx_hash": txHash,
	})
}
