package handler

import (
	"depin-backend/internal/service"
	"encoding/json"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
)

var mqttService *service.MQTTService

func InitMQTTService(s *service.MQTTService) {
	mqttService = s
}

type HeartbeatPayload struct {
	DeviceID  string  `json:"device_id"`
	Power     float64 `json:"power_w"`
	Timestamp int64   `json:"ts"`
}

func HandleMQTTHeartbeat(payload []byte) {
	var hb HeartbeatPayload
	if err := json.Unmarshal(payload, &hb); err != nil {
		log.Println("Invalid MQTT payload:", err)
		return
	}
	log.Printf("Heartbeat from %s: %.2fW", hb.DeviceID, hb.Power)
	// 可选：存入 usage_raw 表等待 Oracle 汇总
}

func HandleHTTPHeartbeat(c *gin.Context) {
	var hb HeartbeatPayload
	if err := c.ShouldBindJSON(&hb); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	HandleMQTTHeartbeat(payload)
	c.JSON(http.StatusOK, gin.H{"status": "received"})
}
