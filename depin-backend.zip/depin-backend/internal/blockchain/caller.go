package blockchain

import (
	"context"
	"crypto/ecdsa"
	"depin-backend/config"
	"depin-backend/internal/blockchain/contracts/bindings"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"math/big"
)

// 获取 Oracle 专用签名者
func getOracleAuth() (*bind.TransactOpts, error) {
	privateKey, err := crypto.HexToECDSA(config.App.OraclePrivateKey)
	if err != nil {
		return nil, err
	}

	publicKey := privateKey.Public()
	publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return nil, err
	}

	fromAddress := crypto.PubkeyToAddress(*publicKeyECDSA)
	nonce, err := Client.PendingNonceAt(context.Background(), fromAddress)
	if err != nil {
		return nil, err
	}

	gasPrice, err := Client.SuggestGasPrice(context.Background())
	if err != nil {
		return nil, err
	}

	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, ChainID)
	if err != nil {
		return nil, err
	}
	auth.Nonce = big.NewInt(int64(nonce))
	auth.Value = big.NewInt(0)
	auth.GasLimit = uint64(300000)
	auth.GasPrice = gasPrice

	return auth, nil
}

// 1. Mint 设备 NFT
func MintDeviceNFT(owner common.Address, deviceID string) (uint64, string, error) {
	auth, err := getOracleAuth()
	if err != nil {
		return 0, "", err
	}

	nftContract, err := bindings.NewDePINDeviceNFT(common.HexToAddress(config.App.ContractNFT), Client)
	if err != nil {
		return 0, "", err
	}

	tx, err := nftContract.MintDevice(auth, owner, deviceID)
	if err != nil {
		return 0, "", err
	}

	receipt, err := bind.WaitMined(context.Background(), Client, tx)
	if err != nil {
		return 0, "", err
	}

	// 解析事件获取 tokenId
	for _, log := range receipt.Logs {
		event, err := nftContract.ParseDeviceMinted(*log)
		if err == nil {
			return event.TokenId.Uint64(), tx.Hash().Hex(), nil
		}
	}
	return 0, tx.Hash().Hex(), nil
}

// 2. Oracle 提交使用数据 + ZK 证明
func SubmitUsageData(deviceID string, usage uint64, ipfsCID string) (string, error) {
	auth, err := getOracleAuth()
	if err != nil {
		return "", err
	}

	rewardContract, err := bindings.NewDePINReward(common.HexToAddress(config.App.ContractReward), Client)
	if err != nil {
		return "", err
	}

	// 模拟 ZK 证明（实际传入 proof bytes）
	dummyProof := [2]*big.Int{big.NewInt(1), big.NewInt(2)}

	tx, err := rewardContract.SubmitUsageData(
		auth,
		deviceID,
		big.NewInt(int64(usage)),
		ipfsCID,
		dummyProof,
	)
	if err != nil {
		return "", err
	}

	return tx.Hash().Hex(), nil
}

// 3. 用户领取奖励
func ClaimRewards(user common.Address) (string, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(
	/* user's private key from frontend */, ChainID,
)
	if err != nil {
		return "", err
	}

	rewardContract, err := bindings.NewDePINReward(common.HexToAddress(config.App.ContractReward), Client)
	if err != nil {
		return "", err
	}

	tx, err := rewardContract.ClaimRewards(auth)
	if err != nil {
		return "", err
	}
	return tx.Hash().Hex(), nil
}
