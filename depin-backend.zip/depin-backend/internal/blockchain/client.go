package blockchain

import (
	"depin-backend/config"
	"github.com/ethereum/go-ethereum/ethclient"
	"log"
	"math/big"
)

var Client *ethclient.Client
var ChainID *big.Int

func init() {
	var err error
	Client, err = ethclient.Dial(config.App.RPCURL)
	if err != nil {
		log.Fatal("Failed to connect to RPC:", err)
	}

	ChainID, err = Client.ChainID(context.Background())
	if err != nil {
		log.Fatal("Failed to get chain ID:", err)
	}
	log.Printf("Connected to chain ID: %s", ChainID.String())
}
