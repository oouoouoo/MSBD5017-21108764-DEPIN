package config

import (
	"github.com/joho/godotenv"
	"log"
	"os"
)

type Config struct {
	RPCURL             string
	OraclePrivateKey   string
	OracleAPIKey       string
	ContractNFT        string
	ContractReward     string
	ContractGovernance string
	JWTSecret          string
	DatabaseURL        string
	MQTTBroker         string
	IPFSNode           string
}

var App Config

func LoadConfig() {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using environment variables")
	}

	App = Config{
		RPCURL:             getEnv("RPC_URL", "https://opt-sepolia.g.alchemy.com/v2/demo"),
		OraclePrivateKey:   getEnv("ORACLE_PRIVATE_KEY", ""),
		OracleAPIKey:       getEnv("ORACLE_API_KEY", "depin-oracle-2025"),
		ContractNFT:        getEnv("CONTRACT_NFT", ""),
		ContractReward:     getEnv("CONTRACT_REWARD", ""),
		ContractGovernance: getEnv("CONTRACT_GOVERNANCE", ""),
		JWTSecret:          getEnv("JWT_SECRET", "depin-super-secret-2025"),
		DatabaseURL:        getEnv("DATABASE_URL", "postgres://depin:depin@localhost:5432/depin?sslmode=disable"),
		MQTTBroker:         getEnv("MQTT_BROKER", "tcp://localhost:1883"),
		IPFSNode:           getEnv("IPFS_NODE", "http://localhost:5001"),
	}
}

func getEnv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
