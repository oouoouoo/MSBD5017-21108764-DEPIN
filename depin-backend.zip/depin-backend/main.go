package main

import (
	"depin-backend/config"
	"depin-backend/internal/handler"
	"depin-backend/internal/middleware"
	"depin-backend/internal/model"
	"depin-backend/internal/repository"
	"depin-backend/internal/service"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"log"
	"time"
)

func main() {
	config.LoadConfig()

	// 初始化数据库
	db, err := gorm.Open(postgres.Open(config.App.DatabaseURL), &gorm.Config{})
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	db.AutoMigrate(&model.Device{}, &model.UsageRaw{}, &model.Proposal{})

	// 初始化 Repository
	deviceRepo := repository.NewDeviceRepository(db)
	usageRepo := repository.NewUsageRepository(db)
	proposalRepo := repository.NewProposalRepository(proposalRepo)

	// 初始化 Service
	ipfsService := service.NewIPFSService(config.App.IPFSNode)
	mqttService := service.NewMQTTService(config.App.MQTTBroker)
	deviceService := service.NewDeviceService(deviceRepo)
	oracleService := service.NewOracleService(deviceRepo, usageRepo, ipfsService)
	rewardService := service.NewRewardService(deviceRepo)
	governanceService := service.NewGovernanceService(proposalRepo)

	// 初始化 Handler
	deviceHandler := handler.NewDeviceHandler(deviceService)
	oracleHandler := handler.NewOracleHandler(oracleService)
	authHandler := handler.NewAuthHandler()
	rewardHandler := handler.NewRewardHandler(rewardService)
	governanceHandler := handler.NewGovernanceHandler(governanceService)

	// Gin 路由
	r := gin.Default()
	r.Use(middleware.CORSMiddleware())
	r.Use(middleware.Recovery())

	// 公开路由
	public := r.Group("/api/v1")
	{
		public.POST("/auth/login", authHandler.Login)
		public.GET("/devices/challenge", deviceHandler.GenerateChallenge)
	}

	// 需要登录的路由
	authorized := r.Group("/api/v1")
	authorized.Use(middleware.AuthMiddleware())
	{
		authorized.POST("/devices/register", deviceHandler.RegisterDevice)
		authorized.GET("/devices/:id", deviceHandler.GetDeviceStatus)
		authorized.POST("/rewards/claim", rewardHandler.ClaimRewards)
		authorized.GET("/rewards/leaderboard", rewardHandler.GetLeaderboard)
		authorized.GET("/governance/proposals", governanceHandler.ListProposals)
	}

	// Oracle 专用内部接口（密钥保护）
	internal := r.Group("/internal/oracle")
	internal.Use(middleware.OracleAuthMiddleware())
	{
		internal.POST("/submit", oracleHandler.SubmitUsageData)
		internal.POST("/heartbeat", handler.HandleMQTTHeartbeat) // 备用通道
	}

	// 启动 MQTT 订阅（备用实时通道）
	go mqttService.SubscribeUsage("depin/usage/#", handler.HandleMQTTHeartbeat)

	// 定时任务：清理1小时前的原始日志
	go func() {
		ticker := time.NewTicker(30 * time.Minute)
		for range ticker.C {
			if affected, err := usageRepo.CleanupOldRaw(1 * time.Hour); err == nil {
				log.Printf("Cleaned %d old raw logs", affected)
			}
		}
	}()

	log.Println("DePIN Backend running on :8080")
	log.Fatal(r.Run(":8080"))
}
